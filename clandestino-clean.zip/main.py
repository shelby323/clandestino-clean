import time

print("Бот запущен и работает в фоне...")

while True:
    print("Still running...")
    time.sleep(10)